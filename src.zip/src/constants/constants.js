export const AUTH = "AUTH";
export const GET_USER_ID = "GET_USER_ID";
export const ADD_TASK = "ADD_TASK";
export const GET_ALL_TASK = "GET_ALL_TASK";
export const GET_SINGLE_TASK = "GET_SINGLE_TASK";
export const UPDATE_TASK = "UPDATE_TASK";
export const DELETE_TASK = "DELETE_TASK";
export const EDIT_BUTTON = "EDIT_BUTTON";
